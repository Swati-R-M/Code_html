package com.fooddelivery;
/**
 * This is an abstract class with abstract method for Resturant
 */
public abstract class Resturant 
{
       
       abstract void display();
       
}
