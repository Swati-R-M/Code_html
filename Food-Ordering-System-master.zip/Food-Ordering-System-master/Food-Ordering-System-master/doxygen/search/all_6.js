var searchData=
[
  ['insertfoodrating_0',['insertFoodRating',['../classcom_1_1fooddelivery_1_1_database_1_1_db_handler.html#a70853a2a571bc436c859cd30cc1e6663',1,'com::fooddelivery::Database::DbHandler']]],
  ['insertuserdata_1',['insertUserData',['../classcom_1_1fooddelivery_1_1_database_1_1_db_handler.html#a644e6c5f4c1bfa83ca596dd210e7d40e',1,'com.fooddelivery.Database.DbHandler.insertUserData(registrationDao reg)'],['../classcom_1_1fooddelivery_1_1_database_1_1_db_handler.html#a462556afa2405ee466a37b343f80a14a',1,'com.fooddelivery.Database.DbHandler.insertUserData(cartDao cartObject)'],['../classcom_1_1fooddelivery_1_1_database_1_1_db_handler.html#aeeffb54372a0983452176f7378a27016',1,'com.fooddelivery.Database.DbHandler.insertUserData(int rating, String email)'],['../classcom_1_1fooddelivery_1_1_database_1_1_dboperation.html#a2856114a823c45e490963617930bcd30',1,'com.fooddelivery.Database.Dboperation.insertUserData()']]]
];
