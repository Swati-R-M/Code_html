var searchData=
[
  ['updateuserdata_0',['updateUserData',['../classcom_1_1fooddelivery_1_1_database_1_1_db_handler.html#a7c54aec6c8f903cc54b6a4dfbaf02d47',1,'com.fooddelivery.Database.DbHandler.updateUserData(loginDao loginObject)'],['../classcom_1_1fooddelivery_1_1_database_1_1_db_handler.html#ac20a18da9dc1ec2306fecb7f3c3ecc3b',1,'com.fooddelivery.Database.DbHandler.updateUserData(wishlistDao w)'],['../classcom_1_1fooddelivery_1_1_database_1_1_dboperation.html#ae350f2896e0e37df9c98d1e593743142',1,'com.fooddelivery.Database.Dboperation.updateUserData()']]],
  ['username_1',['userName',['../classcom_1_1fooddelivery_1_1_authentication_1_1registration_dao.html#a449ba16bf95af7b2845eadcf95716541',1,'com::fooddelivery::Authentication::registrationDao']]]
];
