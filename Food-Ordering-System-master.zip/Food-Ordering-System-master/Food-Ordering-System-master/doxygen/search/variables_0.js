var searchData=
[
  ['actualtime_0',['actualTime',['../classcom_1_1fooddelivery_1_1foodappp.html#a4248b3d12fd909e7780e473ba9c7962f',1,'com::fooddelivery::foodappp']]]
];
