var searchData=
[
  ['logindao_0',['loginDao',['../classcom_1_1fooddelivery_1_1_authentication_1_1login_dao.html',1,'com::fooddelivery::Authentication']]]
];
