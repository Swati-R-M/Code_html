var searchData=
[
  ['authentication_0',['Authentication',['../namespacecom_1_1fooddelivery_1_1_authentication.html',1,'com::fooddelivery']]],
  ['database_1',['Database',['../namespacecom_1_1fooddelivery_1_1_database.html',1,'com::fooddelivery']]],
  ['fooddelivery_2',['fooddelivery',['../namespacecom_1_1fooddelivery.html',1,'com']]]
];
