var searchData=
[
  ['username_0',['userName',['../classcom_1_1fooddelivery_1_1_authentication_1_1registration_dao.html#a449ba16bf95af7b2845eadcf95716541',1,'com::fooddelivery::Authentication::registrationDao']]]
];
