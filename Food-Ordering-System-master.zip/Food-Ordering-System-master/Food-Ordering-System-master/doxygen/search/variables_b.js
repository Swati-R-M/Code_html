var searchData=
[
  ['wishlist_0',['wishList',['../classcom_1_1fooddelivery_1_1_authentication_1_1registration_dao.html#ab24921685e7b1ab80b59a145f952f8dc',1,'com::fooddelivery::Authentication::registrationDao']]],
  ['wishlist_1',['wishlist',['../classcom_1_1fooddelivery_1_1_authentication_1_1login_dao.html#a41a3b519764fc1299f6dcfb54b264f71',1,'com::fooddelivery::Authentication::loginDao']]]
];
