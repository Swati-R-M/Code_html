var searchData=
[
  ['main_0',['main',['../classcom_1_1fooddelivery_1_1foodappp.html#ae3212fe8382f0e4833fd2e2912e2c4bf',1,'com::fooddelivery::foodappp']]]
];
