var searchData=
[
  ['lat_0',['lat',['../classcom_1_1fooddelivery_1_1foodappp.html#a108600a85869d20a710a98387986fe9d',1,'com::fooddelivery::foodappp']]],
  ['latitude_1',['latitude',['../classcom_1_1fooddelivery_1_1resturant_dao.html#acc70a3076e0a1e1eca8dbd1fd7eb9577',1,'com::fooddelivery::resturantDao']]],
  ['listofrestaurants_2',['listOfRestaurants',['../classcom_1_1fooddelivery_1_1foodappp.html#a3a9e58605e89853eedb6516d70154de5',1,'com::fooddelivery::foodappp']]],
  ['login_3',['login',['../classcom_1_1fooddelivery_1_1foodappp.html#ab794a8f00dda9a7652bf41d140a41afd',1,'com::fooddelivery::foodappp']]],
  ['logincheck_4',['logincheck',['../classcom_1_1fooddelivery_1_1_database_1_1_db_handler.html#a7ceee4b1ddd04d0be9dc2dc290cb6375',1,'com::fooddelivery::Database::DbHandler']]],
  ['logindao_5',['loginDao',['../classcom_1_1fooddelivery_1_1_authentication_1_1login_dao.html',1,'com::fooddelivery::Authentication']]],
  ['logindao_2ejava_6',['loginDao.java',['../login_dao_8java.html',1,'']]],
  ['lon_7',['lon',['../classcom_1_1fooddelivery_1_1foodappp.html#ad26f54eabbd1698e4388637a44b54ab8',1,'com::fooddelivery::foodappp']]],
  ['longitude_8',['longitude',['../classcom_1_1fooddelivery_1_1resturant_dao.html#ad3e1a2fa9067bb50ce8eead2cbae0a5f',1,'com::fooddelivery::resturantDao']]]
];
