var indexSectionsWithContent =
{
  0: "acdefgilmopqrstuw",
  1: "acdflprsw",
  2: "c",
  3: "acdflprsw",
  4: "acdfgilmpqrstuw",
  5: "acdefloprtuw",
  6: "f"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables",
  6: "Pages"
};

