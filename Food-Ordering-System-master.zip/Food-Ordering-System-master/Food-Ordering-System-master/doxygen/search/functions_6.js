var searchData=
[
  ['login_0',['login',['../classcom_1_1fooddelivery_1_1foodappp.html#ab794a8f00dda9a7652bf41d140a41afd',1,'com::fooddelivery::foodappp']]],
  ['logincheck_1',['logincheck',['../classcom_1_1fooddelivery_1_1_database_1_1_db_handler.html#a7ceee4b1ddd04d0be9dc2dc290cb6375',1,'com::fooddelivery::Database::DbHandler']]]
];
