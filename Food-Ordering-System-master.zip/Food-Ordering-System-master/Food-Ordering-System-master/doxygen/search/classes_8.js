var searchData=
[
  ['wishlistdao_0',['wishlistDao',['../classcom_1_1fooddelivery_1_1wishlist_dao.html',1,'com::fooddelivery']]]
];
