var searchData=
[
  ['dbhandler_0',['DbHandler',['../classcom_1_1fooddelivery_1_1_database_1_1_db_handler.html',1,'com::fooddelivery::Database']]],
  ['dboperation_1',['Dboperation',['../classcom_1_1fooddelivery_1_1_database_1_1_dboperation.html',1,'com::fooddelivery::Database']]]
];
